function [INF,SUP] = VARirband(VAR,IRF_opt,ndraws,method)
% =======================================================================
% Calculates confidence intervals for impulse response functions computed
% with VARir
% =======================================================================
% [INF,SUP] = VARirband(VAR,IRF_opt,ndraws,method)
% -----------------------------------------------------------------------
% INPUTS 
%   VAR     = VAR results obtained with VARmodel (structure)
%	IRF_opt = options of the IRFs (is the output of VARir)
%
% OPTIONAL INPUTS
%   ndraws    = number of draws for the MC algorithm (or boostrapping) [default 100]
%   method    = 'mc' for Montecarlo simulation, 'bs' for Bootstrapping [default 'bs']
%
% OUTPUT
%   INF(t,j,k) = lower confidence band (t steps, j variable, k shock)
%   SUP(t,j,k) = upper confidence band (t steps, j variable, k shock)
% =======================================================================
% Ambrogio Cesa Bianchi, July 2012
% ambrogio.cesabianchi@gmail.com


%% Retrieve some parameters from the structure VAR and IRF_opt
%=============================================================

nsteps = IRF_opt.nsteps;
impact = IRF_opt.impact;
ident  = IRF_opt.ident;
invA   = IRF_opt.invA;

beta     = VAR.beta;
nvars    = VAR.neqs;
nvar_ex  = VAR.nvar_ex;
nlags    = VAR.nlag;
c_case   = VAR.c_case;
nobs     = VAR.nobs;
pctg     = 0.05;
Y        = VAR.Y;
resid    = VAR.residuals;


%% Check inputs 
%============================

if ~exist('ndraws','var')
    ndraws = 100;
end

if ~exist('method','var')
    method = 'bs';
end

INF = zeros(nsteps,nvars,nvars);
SUP = zeros(nsteps,nvars,nvars);

%% Create the matrices for the loop
%==================================

y_artificial = zeros(2*nobs,nvars);
LAG = zeros(1,nvars*nlags);
u = zeros(2*nobs,nvars);


%% Loop over the number of draws, generate data, estimate the var and then 
%% calculate impulse response functions
%==========================================================================

for tt=1:ndraws
    disp(['Loop ' num2str(tt) ' / ' num2str(ndraws) ' draws'])

%% STEP 1: choose the method (Monte Carlo or Bootstrap) and generate the 
%% residuals
    if strmatch(method,'mc')
        % create the structural error terms epsilon ~ N(0,1)
        epsilon = randn(2*nobs,nvars); 
        for jj=1:2*nobs
            % compute back the reduced form VAR error terms (u)
            u(jj,:) = epsilon(jj,:)*invA;
        end
    elseif strmatch(method,'bs')
        % Use the residuals to bootstrap: generate a random number bounded 
        % between 0 and # of residuals, then use the ceil function to select 
        % that row of the residuals (this is equivalent to sampling with replacement)
        u = resid(ceil(size(resid,1)*rand(2*nobs,1)),:);
    end

%% STEP 2: generate the artifcial data

%% STEP 2.1: generate initial values for the artifcial data
    % Intialize the first nlags observations with real data + plus artificial
    % res. Nontheless, in the estimation of the var on the simulated data, 
    % I through away the first nobs observations so it should not matter.
    LAG=[];
    for k = 1:nlags
        y_artificial(k,:) = Y(k,:) + u(k,:);
        LAG = [y_artificial(k,:) LAG]; 
        % Initialize the artificial series and the LAGplus vector
        if c_case==0
            LAGplus = LAG;
        elseif c_case==1
            LAGplus = [1 LAG];
        elseif c_case==2
            T = [1:2*nobs]';
            LAGplus = [1 T(k) LAG]; %!there was a prob here. solved!
        end
    end
    
%% STEP 2.2: generate artificial series 
    % From observation nlags+1 to 2*nobs, compute the artificial data
    for jj = nlags+1:2*nobs
        for mm = 1:nvars
            % Compute the value for time=jj
            y_artificial(jj,mm) = LAGplus * beta(1:end-nvar_ex,mm) + u(jj,mm);
        end
        % now update the LAG matrix
        LAG = [y_artificial(jj,:) LAG(1,1:(nlags-1)*nvars)];
        if c_case==1
            LAGplus = [1 LAG];
        elseif c_case==2
            LAGplus = [1 T(jj) LAG]; %!there was a prob here. solved!
        end
    end

%% STEP 3: estimate VAR on artificial data. 
    % I throw away the first nobs observations as I want to avoid any 
    % starting value problems
    if exist('VAR.exog','var')
        VAR_draw = VARmodel(y_artificial(1*nobs+1:end,:),nlags,c_case,VAR.exog);
    else
        VAR_draw = VARmodel(y_artificial(1*nobs+1:end,:),nlags,c_case);
    end
    
    beta_draw  = VAR_draw.beta;
    sigma_draw = VAR_draw.sigma;

%% STEP 4: calculate "ndraws" impulse responses and store them
    irf_draw = VARir(VAR_draw,nsteps,ident,impact);
    
    % if you don't have three dimensional arrays this will break.
    IRF(:,:,:,tt) = irf_draw;
    
end

%% Compute the error bands
%=========================
for mm = 1:nvars
    
    if strmatch(method,'mc') % When using montecarlo use st. dev bands type

        if strmatch(ident,'bq')
            disp(' ');
            disp('Error: Monte Carlo error bands not available');
            disp('       with Blanchard-Quah identification');
            disp(' ');
            return
        end
    
        % Demean the drawed impulse responses
        for zx = 1:nvars;
            for zy = 1:nsteps;
                IRF_demean(zy,zx,mm,:) = IRF(zy,zx,mm,:) - mean(IRF(zy,zx,mm,:),4);
            end
        end
        
        % Compute the true IRF to use it as a mean
        IRF_true = VARir(VAR,nsteps);
        
        % Compute the variance of IRF demean and then the error bands
        variance(:,:,mm) = (1/ndraws)*sum(IRF_demean(:,:,mm,:).^2,4);
        INF(:,:,mm)      = IRF_true(:,:,mm) - 2*sqrt(variance(:,:,mm));
        SUP(:,:,mm)      = IRF_true(:,:,mm) + 2*sqrt(variance(:,:,mm));

    elseif strmatch(method,'bs') % When using boostratp, use percentile (upper and lower bounds) bands type

        % Sort the impulse responses
        IRF_sort(:,:,mm,:) = sort(IRF(:,:,mm,:),4);
        
        % Get the percentiles
        INF(:,:,mm) = squeeze(IRF_sort(:,:,mm,round(pctg*ndraws)));
        SUP(:,:,mm) = squeeze(IRF_sort(:,:,mm,round((1-pctg)*ndraws)));

    end

end

