function [BETA, TSTAT]= VARprint(VAR,end_names,ex_names)
% =======================================================================
% Prints the output of a VAR estimation
% =======================================================================
% BETA = VARprint(VAR,end_names)
% -----------------------------------------------------------------------
% INPUT
%   VAR       : structure output of VARmodel function
%   end_names : endogebnous names of the variables
%
% OPTIONAL INPUT
%   ex_names  : exogenous names of the variables
% OUPUT
%   BETA: table in cell array
% =======================================================================
% Ambrogio Cesa Bianchi, May 2012
% ambrogio.cesabianchi@gmail.com



nlags     = VAR.nlag;
nlags_ex  = VAR.nlag_ex;
c_case = VAR.c_case;

htext = end_names;
vtext = {' '};

if size(end_names,2)==1
    end_names = end_names';
    nvars = size(end_names,2);
else
    nvars = size(end_names,2);
end

if ~exist('ex_names','var')
    ex_names = [];
    nvars_ex = 0;
else
    if size(ex_names,2)==1
        ex_names = ex_names';
        nvars_ex = size(ex_names,2);
    else
        nvars_ex = size(ex_names,2);
    end
end

% Labels of deterministic components
switch c_case
    case 0
        aux = [];            
    case 1
        aux = {'c'};
    case 2
        aux = {'c';'trend'};
end
vtext = [vtext; aux];
clear aux

% Labels of lagged variables
for jj=1:nlags
    for ii=1:nvars
        aux(ii,1) = {[end_names{ii} '(-' num2str(jj) ')' ]};
    end
    vtext = [vtext ; aux];
end
clear aux

% Labels of exogenous variables
vtext = [vtext ; ex_names'];
if nlags_ex > 0
    for jj=1:nlags_ex
        for ii=1:nvars_ex
            aux(ii,1) = {[ex_names{ii} '(-' num2str(jj) ')' ]};
        end
        vtext = [vtext ; aux];
    end
    clear aux
end

% Save a BETA table
BETA = [htext; num2cell(VAR.beta)];
BETA = [vtext BETA];

% Save a TSTAT table
TSTAT = [];
for ii=1:nvars
    eval( ['aux = VAR.eq' num2str(ii) '.tstat;'] );
    TSTAT = [TSTAT aux];
end
TSTAT = [htext; num2cell(TSTAT)];
TSTAT = [vtext TSTAT];

% Print the table
info.cnames = char(htext);
info.rnames = char(vtext);
disp(' ')
disp('---------------------------------------------------------------------')
disp(' ')
disp('Reduced form VAR estimation:')
disp(' ')
mprint(VAR.beta,info)
disp('---------------------------------------------------------------------')
        
    