function VARirplot(IRF,labels,filename,INF,SUP)
% =======================================================================
% Plot the IRFs computed with VARirfs or BVARirfs
% =======================================================================
% VARirplot(IRF,labels,filename,INF,SUP)
% -----------------------------------------------------------------------
% INPUT
%   IRF(:,:,:) : matrix with periods, variable, shock
%
% OPTIONAL INPUT
%   labels   : name of the variables, ordered as in the choleski
%   filename : name for file saving
%   INF      : lower error band
%   SUP      : upper error band
% =======================================================================
% Ambrogio Cesa Bianchi, May 2012
% ambrogio.cesabianchi@gmail.com


%% Check optional inputs
%=========================
if ~exist('filename','var') 
    filename = 'shock_';
end


%% Define some parameters
%========================

% Initialize IRF matrix
[nsteps nvars nshocks] = size(IRF);

% Define the rows and columns for the subplots
row = round(sqrt(nvars));
col = ceil(sqrt(nvars));

% Define a timeline
irf_step = 1:1:nsteps;
x_axis = zeros(1,nsteps);


%% Plot
%=========
for jj = 1:nshocks
    for ii=1:nvars
        subplot(row,col,ii);
        plot(irf_step,IRF(:,ii,jj),'LineStyle','-','Color',rgb('dark blue'),'LineWidth',2);
        hold on
        plot(x_axis,'k','LineWidth',0.5)
        if exist('INF','var') && exist('SUP','var')
            plot(irf_step,INF(:,ii,jj),'LineStyle',':','Color',rgb('light blue'),'LineWidth',1.5);
            hold on
            plot(irf_step,SUP(:,ii,jj),'LineStyle',':','Color',rgb('light blue'),'LineWidth',1.5);
        end
        xlim([1 nsteps]);
        if exist('labels','var') 
            title(labels(ii), 'FontWeight','bold','FontSize',10); 
        end
        set(gca,'FontSize',8);
        xlabel('Quarters after shock');
    end
    
    if exist('labels','var')
        SupTitle( ['Shock to ' char(labels(jj)) ' equation' ] );
    end
   
    % Save
    set(gcf, 'Color', 'w');
    FigSize(24,16)
    FigName = [filename num2str(jj)];
    export_fig(FigName,'-pdf','-png','-painters')
    clf('reset');
end

close all
