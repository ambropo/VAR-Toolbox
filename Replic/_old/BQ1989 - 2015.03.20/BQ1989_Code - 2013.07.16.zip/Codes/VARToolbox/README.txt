If you find any bugs or want to give me comments and suggestions you can email me at ambrogio.cesabianchi@gmail.com

If you happen to use these codes for research papers can you please quote (in your acknowledgements or in a footnote) as follows: "VAR estimation are performed with the VAR Toolbox by Ambrogio Cesa-Bianchi, available at sites.google.com/site/ambropo/".